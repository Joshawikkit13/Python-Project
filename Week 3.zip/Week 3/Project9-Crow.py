Kilometers = float(input("Enter distance (in kilometers) traveled."))
#nautical miles for every 100km = 54
nauticalMiles = Kilometers * .54
print("Your distance is", nauticalMiles, "nautical miles.")
input("Press any key, then press enter to exit.")