edge = float(input("Enter an edge "))
surfaceArea = edge * edge * 6
print(surfaceArea, "is your cube's surface area.a")
input("Press any key, then press enter to exit.")