Mass = float(input("Enter your object's mass in kilograms."))
Velocity = float(input("Enter your object's velocity in meters per second."))
Momentum = Mass * Velocity
print(Momentum, "kg is your object's momentum.")
input("Press any key, then press enter to exit.")