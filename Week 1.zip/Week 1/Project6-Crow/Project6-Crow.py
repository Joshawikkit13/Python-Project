radius = float(input("Enter the circle's radius."))
area = radius * 3.14 * 2
print ("The area of the circle is ", area)
input("Press any key, then enter to exit.")